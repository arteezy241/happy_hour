import { 
  type Category, 
  type Product, 
  type CartItem, 
  type Order,
  type InsertCartItem,
  type InsertOrder
} from "@shared/schema";
import { randomUUID } from "crypto";

const categories: Category[] = [
  { id: "whiskey", name: "Whiskey", description: "Premium whiskeys from around the world" },
  { id: "vodka", name: "Vodka", description: "Crystal clear vodkas for any occasion" },
  { id: "rum", name: "Rum", description: "Caribbean and tropical rums" },
  { id: "tequila", name: "Tequila", description: "Authentic Mexican tequilas" },
  { id: "gin", name: "Gin", description: "Botanical gins for cocktail lovers" },
  { id: "wine", name: "Wine", description: "Red, white, and sparkling wines" },
  { id: "beer", name: "Beer", description: "Craft beers and imported selections" },
];

const products: Product[] = [
  {
    id: "1",
    name: "Johnnie Walker Black Label",
    categoryId: "whiskey",
    description: "A masterful blend of single malt and grain whiskies aged for a minimum of 12 years. Rich, smooth, and complex with notes of dried fruits and smoky malt.",
    price: 34.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=400",
    tags: ["scotch", "blended", "premium"],
    isFeatured: true,
    stock: 50
  },
  {
    id: "2",
    name: "Grey Goose Vodka",
    categoryId: "vodka",
    description: "French vodka distilled from the finest soft winter wheat and pure spring water. Exceptionally smooth with subtle sweetness.",
    price: 29.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1614313511387-1436a4480ebb?w=400",
    tags: ["french", "premium", "smooth"],
    isFeatured: true,
    stock: 75
  },
  {
    id: "3",
    name: "Bacardi Superior White Rum",
    categoryId: "rum",
    description: "Light-bodied rum with delicate floral and fruity notes. Perfect for cocktails like Mojitos and Daiquiris.",
    price: 16.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1598018553943-87ec4def8086?w=400",
    tags: ["white rum", "cocktail", "caribbean"],
    isFeatured: false,
    stock: 100
  },
  {
    id: "4",
    name: "Patrón Silver Tequila",
    categoryId: "tequila",
    description: "Handcrafted from 100% Weber Blue Agave. Crystal clear with fresh agave aroma and hints of citrus and pepper.",
    price: 44.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1569529465841-dfecdab7503b?w=400",
    tags: ["silver", "premium", "100% agave"],
    isFeatured: true,
    stock: 40
  },
  {
    id: "5",
    name: "Tanqueray London Dry Gin",
    categoryId: "gin",
    description: "A classic London dry gin with four botanicals: juniper, coriander, angelica, and licorice. Bold and crisp.",
    price: 24.99,
    volume: "750ml",
    abv: 47.3,
    imageUrl: "https://images.unsplash.com/photo-1608885898957-a559228e8749?w=400",
    tags: ["london dry", "classic", "botanicals"],
    isFeatured: false,
    stock: 60
  },
  {
    id: "6",
    name: "Moet & Chandon Brut Imperial",
    categoryId: "wine",
    description: "A prestigious champagne with bright fruitiness and elegant maturity. Perfect for celebrations.",
    price: 54.99,
    volume: "750ml",
    abv: 12,
    imageUrl: "https://images.unsplash.com/photo-1594372365401-3b5ff14eaaed?w=400",
    tags: ["champagne", "sparkling", "celebration"],
    isFeatured: true,
    stock: 30
  },
  {
    id: "7",
    name: "Jack Daniel's Old No.7",
    categoryId: "whiskey",
    description: "The iconic Tennessee whiskey, charcoal mellowed for smooth character with notes of caramel and vanilla.",
    price: 27.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1609767530648-b9d4956c2bf1?w=400",
    tags: ["tennessee", "american", "classic"],
    isFeatured: false,
    stock: 85
  },
  {
    id: "8",
    name: "Absolut Vodka",
    categoryId: "vodka",
    description: "Swedish vodka made from winter wheat. Rich, full-bodied and complex with hints of grain and dried fruit.",
    price: 19.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1608270586620-248524c67de9?w=400",
    tags: ["swedish", "wheat", "versatile"],
    isFeatured: false,
    stock: 90
  },
  {
    id: "9",
    name: "Captain Morgan Original Spiced Rum",
    categoryId: "rum",
    description: "Caribbean rum blended with spices for a smooth and sweet taste with vanilla, oak, and cinnamon notes.",
    price: 18.99,
    volume: "750ml",
    abv: 35,
    imageUrl: "https://images.unsplash.com/photo-1514218953589-2d7d37efd2dc?w=400",
    tags: ["spiced", "caribbean", "smooth"],
    isFeatured: true,
    stock: 70
  },
  {
    id: "10",
    name: "Don Julio Reposado",
    categoryId: "tequila",
    description: "Aged for eight months in American white-oak barrels. Rich, smooth with notes of dark chocolate and cinnamon.",
    price: 54.99,
    volume: "750ml",
    abv: 40,
    imageUrl: "https://images.unsplash.com/photo-1566811555939-bb9c9cb2d6ad?w=400",
    tags: ["reposado", "aged", "premium"],
    isFeatured: false,
    stock: 35
  },
  {
    id: "11",
    name: "Hendrick's Gin",
    categoryId: "gin",
    description: "Scottish gin infused with cucumber and rose petals. Delightfully floral with a subtle and balanced taste.",
    price: 34.99,
    volume: "750ml",
    abv: 44,
    imageUrl: "https://images.unsplash.com/photo-1619451334792-150fd785ee74?w=400",
    tags: ["scottish", "cucumber", "floral"],
    isFeatured: true,
    stock: 45
  },
  {
    id: "12",
    name: "Chateau Margaux 2015",
    categoryId: "wine",
    description: "Premier Grand Cru Classé from Bordeaux. Deep ruby color with complex aromas of blackcurrant and violet.",
    price: 649.99,
    volume: "750ml",
    abv: 13.5,
    imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=400",
    tags: ["bordeaux", "red wine", "luxury"],
    isFeatured: false,
    stock: 10
  },
];

export interface IStorage {
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  getProductsByCategory(categoryId: string): Promise<Product[]>;
  getFeaturedProducts(): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  
  getCart(sessionId: string): Promise<CartItem[]>;
  getCartItem(sessionId: string, productId: string): Promise<CartItem | undefined>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: string, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: string): Promise<void>;
  clearCart(sessionId: string): Promise<void>;
  
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
  getOrdersBySession(sessionId: string): Promise<Order[]>;
}

export class MemStorage implements IStorage {
  private categoriesData: Map<string, Category>;
  private productsData: Map<string, Product>;
  private cartItems: Map<string, CartItem>;
  private orders: Map<string, Order>;

  constructor() {
    this.categoriesData = new Map(categories.map(c => [c.id, c]));
    this.productsData = new Map(products.map(p => [p.id, p]));
    this.cartItems = new Map();
    this.orders = new Map();
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categoriesData.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categoriesData.get(id);
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.productsData.get(id);
  }

  async getProductsByCategory(categoryId: string): Promise<Product[]> {
    return Array.from(this.productsData.values()).filter(p => p.categoryId === categoryId);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return Array.from(this.productsData.values()).filter(p => p.isFeatured);
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.productsData.values()).filter(p => 
      p.name.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery) ||
      p.tags?.some(t => t.toLowerCase().includes(lowerQuery))
    );
  }

  async getCart(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(item => item.sessionId === sessionId);
  }

  async getCartItem(sessionId: string, productId: string): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      item => item.sessionId === sessionId && item.productId === productId
    );
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    const existing = await this.getCartItem(insertItem.sessionId, insertItem.productId);
    if (existing) {
      const updated = await this.updateCartItem(existing.id, existing.quantity + insertItem.quantity);
      return updated!;
    }
    const id = randomUUID();
    const item: CartItem = { ...insertItem, id };
    this.cartItems.set(id, item);
    return item;
  }

  async updateCartItem(id: string, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    const updated = { ...item, quantity };
    this.cartItems.set(id, updated);
    return updated;
  }

  async removeFromCart(id: string): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<void> {
    const toRemove = Array.from(this.cartItems.entries())
      .filter(([_, item]) => item.sessionId === sessionId)
      .map(([id]) => id);
    toRemove.forEach(id => this.cartItems.delete(id));
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      status: "pending",
      createdAt: new Date().toISOString(),
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersBySession(sessionId: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(o => o.sessionId === sessionId);
  }
}

export const storage = new MemStorage();
