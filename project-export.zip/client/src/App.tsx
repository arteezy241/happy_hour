import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider, useCart } from "@/lib/cart";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Shop from "@/pages/Shop";
import ProductDetail from "@/pages/ProductDetail";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import OrderConfirmation from "@/pages/OrderConfirmation";
import { ShoppingCart, Home as HomeIcon, Store, Menu, X } from "lucide-react";
import { useState } from "react";

function Navigation() {
  const { itemCount } = useCart();
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <nav className="bg-white border-b sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <span className="font-['Playfair_Display'] text-xl font-bold cursor-pointer">
              Happy Hour Liquors
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/">
              <span className={`flex items-center gap-2 cursor-pointer font-['Poppins'] ${isActive('/') ? 'text-black' : 'text-gray-500 hover:text-black'}`}>
                <HomeIcon size={18} />
                Home
              </span>
            </Link>
            <Link href="/shop">
              <span className={`flex items-center gap-2 cursor-pointer font-['Poppins'] ${isActive('/shop') ? 'text-black' : 'text-gray-500 hover:text-black'}`}>
                <Store size={18} />
                Shop
              </span>
            </Link>
            <Link href="/cart">
              <span className="flex items-center gap-2 cursor-pointer font-['Poppins'] text-gray-500 hover:text-black relative">
                <ShoppingCart size={18} />
                Cart
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-4 bg-[#333333] text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </span>
            </Link>
          </div>

          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link href="/" onClick={() => setMobileMenuOpen(false)}>
              <span className="flex items-center gap-2 py-2 font-['Poppins']">
                <HomeIcon size={18} />
                Home
              </span>
            </Link>
            <Link href="/shop" onClick={() => setMobileMenuOpen(false)}>
              <span className="flex items-center gap-2 py-2 font-['Poppins']">
                <Store size={18} />
                Shop
              </span>
            </Link>
            <Link href="/cart" onClick={() => setMobileMenuOpen(false)}>
              <span className="flex items-center gap-2 py-2 font-['Poppins']">
                <ShoppingCart size={18} />
                Cart ({itemCount})
              </span>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/shop" component={Shop} />
      <Route path="/product/:id" component={ProductDetail} />
      <Route path="/cart" component={Cart} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/order-confirmation/:id" component={OrderConfirmation} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <CartProvider>
        <TooltipProvider>
          <Toaster />
          <Navigation />
          <Router />
        </TooltipProvider>
      </CartProvider>
    </QueryClientProvider>
  );
}

export default App;
